---
name: design-critique
description: >
  Review and critique OpenELIS design mockups for usability, accessibility,
  consistency with Carbon Design System, and clinical laboratory workflow
  correctness. Trigger when the user says "critique this design", "review
  this mockup", "what do you think of this UI", "is this mockup good",
  "design feedback", or asks for opinions on a gallery mockup.
version: 0.1.0
---

# Design Critique for OpenELIS Mockups

Evaluate OpenELIS design mockups against clinical laboratory UX best practices, Carbon Design System conventions, and real-world lab workflow requirements.

## Critique Framework

Assess each mockup across these dimensions, scoring 1-5 and providing specific observations:

### 1. Clinical Workflow Fit
- Does the flow match how lab technicians actually work?
- Are steps ordered to minimize context switching?
- Does it handle the critical path efficiently (high-volume, routine tasks)?
- Are edge cases covered (STAT orders, reruns, critical values, QC failures)?
- Does it respect the "gloves-on" reality (minimal typing, large touch targets)?

### 2. Carbon Design System Compliance
- Uses Carbon components correctly (DataTable, Tabs, Modal, Notification, Breadcrumb)
- Follows Carbon grid (16-column, 32px gutter)
- Uses Carbon color tokens (`$interactive-01`, `$danger-01`, `$support-error`)
- Typography follows Carbon scale (productive vs. expressive)
- Icons from `@carbon/icons-react`, 16px/20px/24px/32px sizes

### 3. Information Hierarchy
- Is the most important information visible without scrolling?
- Are data tables scannable (key columns leftmost, status badges, row actions)?
- Does progressive disclosure work (summary → detail → full record)?
- Are empty states, loading states, and error states designed?

### 4. Accessibility (WCAG 2.1 AA)
- Color contrast ratios (4.5:1 text, 3:1 large text, 3:1 UI components)
- Focus management for modals and drawers
- Screen reader landmarks and aria-labels
- Keyboard navigation paths
- No color-only indicators (pair with icons or text)

### 5. Data Integrity & Safety
- Are destructive actions confirmed? (delete, reject, release results)
- Is audit trail information visible where needed?
- Are required fields clearly marked?
- Does validation happen inline with clear error messages?
- Is the "release results" action appropriately protected?

## Output Format

Structure the critique as:

1. **Summary** — One paragraph overall assessment
2. **Strengths** — What works well (2-4 points)
3. **Issues** — Specific problems with severity (Critical / Major / Minor)
4. **Recommendations** — Actionable improvements with priority
5. **Score Card** — Table with the 5 dimensions scored 1-5

## OpenELIS-Specific Considerations

- Multi-site deployments: designs must work for labs in LMICs with varying connectivity
- Bilingual support: French and English are primary; layouts must accommodate text expansion
- Role-based views: Technician, Validator, Admin, Pathologist see different things
- Integration points: HL7/FHIR messages, analyzer interfaces, EMR connections
- Regulatory: ISO 15189, WHO SLIPTA requirements for lab accreditation
