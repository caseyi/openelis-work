---
name: spec-review
description: >
  Review OpenELIS functional requirement specifications (FRS) for completeness,
  technical feasibility, and implementation readiness. Trigger when the user
  says "review this spec", "is this FRS complete", "check the requirements",
  "spec review", "what's missing from this spec", or asks about the quality
  of a design specification document.
version: 0.1.0
---

# Spec Review for OpenELIS FRS Documents

Evaluate functional requirement specifications for completeness, clarity, technical feasibility, and readiness for implementation by the OpenELIS development team.

## Review Checklist

### 1. Structure & Completeness

Every FRS should include:
- **Overview/Purpose** — What problem this solves and for whom
- **Key Concepts** — Domain terms defined (especially lab-specific terminology)
- **User Stories or Use Cases** — Who does what and why
- **Functional Requirements** — Specific, testable requirements with IDs
- **Data Model** — Tables, fields, relationships, constraints
- **API Endpoints** — REST endpoints with request/response schemas
- **UI Requirements** — Page layouts, component behavior, state management
- **Validation Rules** — Input validation, business rules, error handling
- **Security & Permissions** — Role-based access, required permissions
- **Migration/Upgrade Path** — How existing data is handled

### 2. Technical Feasibility

- Can this be built on the existing OpenELIS Spring Boot + React stack?
- Are there database schema changes? Are they backward-compatible?
- Does it require new REST endpoints or modifications to existing ones?
- Are there external dependencies (new libraries, services, APIs)?
- Does it integrate with existing OpenELIS modules correctly?
- Are FHIR resource mappings specified where applicable?

### 3. Requirement Quality

Each functional requirement should be:
- **Specific** — One behavior per requirement, no ambiguity
- **Measurable** — Clear pass/fail criteria
- **Achievable** — Within the team's technical capability
- **Relevant** — Traces to a user need or regulatory requirement
- **Testable** — Can write an acceptance test from the requirement

Flag requirements that are vague ("the system should be user-friendly"), compound ("the system should validate AND save AND notify"), or untestable.

### 4. OpenELIS Architecture Alignment

- **Frontend**: React with Carbon Design System components
- **Backend**: Spring Boot with Hibernate ORM
- **Database**: PostgreSQL
- **APIs**: REST with OpenAPI/Swagger docs
- **Auth**: Spring Security with role-based access
- **i18n**: MessageSource-based, French + English minimum
- **Testing**: JUnit + Mockito backend, React Testing Library frontend

### 5. Implementation Readiness

- Can a developer start coding from this spec without additional questions?
- Are edge cases documented?
- Are error states and recovery paths specified?
- Is the scope clear (what's in vs. out)?
- Are dependencies on other features/modules identified?
- Is there a suggested implementation order or phasing?

## Output Format

1. **Summary** — Overall assessment and readiness rating (Ready / Needs Work / Major Gaps)
2. **Strengths** — What's well-specified
3. **Gaps** — Missing sections or underspecified areas, ranked by impact
4. **Ambiguities** — Requirements that need clarification
5. **Technical Concerns** — Feasibility issues or architecture questions
6. **Recommendations** — Prioritized list of improvements before implementation

## Jira Integration

When reviewing specs, note which requirements map to existing Jira stories in the OGC project. Flag requirements that need new Jira stories created. The Jira project is OGC on uwdigi.atlassian.net.
