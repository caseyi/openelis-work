---
name: process-design
description: >
  Process uploaded design files into the OpenELIS design gallery. Trigger when
  the user says "I added new files", "process uploads", "add this to the gallery",
  "new spec uploaded", "new mockup", or mentions files in the upload/ folder that
  need to be integrated. Also trigger on "give me permalinks" or "add to gallery".
version: 0.1.0
---

# Process Design Files into Gallery

Process new design files from `upload/` into the OpenELIS design gallery workspace.

## Workflow

### 1. Discover New Files

Check `upload/` for files not yet in `designs/`:

```bash
ls -lt upload/ | head -20
```

Identify file pairs (mockup + spec) and standalone files. Common patterns:
- `.jsx` → JSX mockup (React component)
- `.html` → HTML mockup (iframe-embedded)
- `.md` → Spec / FRS / PRD
- `.docx` → Keep as asset, use `.md` version for gallery

### 2. Determine Category and Naming

Read the first 20-30 lines of each file to understand its purpose. Match to an existing category or create a new one. See `references/gallery-architecture.md` for the full category list.

Rename to kebab-case: `OpenELIS_Feature_Name_FRS.md` → `feature-name.md`

### 3. Copy to Proper Location

```bash
mkdir -p designs/<category>/
cp upload/<file> designs/<category>/<kebab-name>
```

For HTML mockups, also copy to `mockup-viewer/public/`:
```bash
mkdir -p mockup-viewer/public/designs/<category>/
cp designs/<category>/<file>.html mockup-viewer/public/designs/<category>/
```

### 4. Update Three Files

**Always update all three** — MANIFEST.yaml, mockup-viewer/src/App.jsx, and INDEX.md.

Read each file before editing. Follow the exact patterns documented in `references/gallery-architecture.md`.

**MANIFEST.yaml** — Add entries with id, type, path, category, description, paired_with, links, added date.

**App.jsx** — Add to MOCKUP_REGISTRY array in the correct category section:
- JSX: use `React.lazy(() => import('@designs/category/file.jsx'))` with `specPath`
- HTML: use `component: null` with `htmlUrl` and `specPath`
- Spec-only: use `component: null` with only `specPath`
- Figma: use `component: null` with `figmaUrl`

If adding a new category, also update the `categories` array and `categoryLabels` object.

**INDEX.md** — Add row to the appropriate section table.

### 5. Build and Verify

```bash
cd mockup-viewer && npm run build 2>&1 | tail -5
```

Build must succeed with `✓ built in` message. If errors occur, fix before proceeding.

### 6. Commit

Stage only the relevant files:
```bash
git add designs/<category>/ MANIFEST.yaml INDEX.md mockup-viewer/src/App.jsx
# If HTML mockup:
git add mockup-viewer/public/designs/<category>/
```

Commit with descriptive message. Always include:
```
Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
```

### 7. Generate Permalinks

Compute the slug: `name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')`

Provide full URLs:
- Gallery mockup: `https://digi-uw.github.io/openelis-work/#/<category>/<slug>`
- GitHub spec: `https://github.com/digi-uw/openelis-work/blob/main/designs/<category>/<filename>.md`

Remind the user to `git push origin main` since the VM has no GitHub credentials.

## Important Rules

- All specs credit "Casey Iiams-Hauser" — never mention Claude/AI authorship
- Use kebab-case for all filenames
- Always read files before editing them
- HTML mockups need both a `designs/` copy and a `mockup-viewer/public/` copy
- Build must pass before committing
- Jira project key is OGC on uwdigi.atlassian.net
- Confluence cloudId: `57b4e32d-23d4-4a71-8985-82ac0274d145`
