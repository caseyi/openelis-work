# Design Gallery Architecture Reference

## Repository Structure

```
openelis-work/
├── designs/                          # Co-located design files
│   ├── admin-config/                 # Category folders
│   ├── analyzer-integration/
│   ├── microbiology/
│   ├── nce/
│   ├── pathology/
│   ├── quality/
│   ├── results-validation/
│   ├── sample-collection/
│   ├── rbac/
│   ├── validation-page/
│   └── system/
├── mockup-viewer/                    # Vite + React gallery app
│   ├── src/App.jsx                   # Gallery registry & viewer
│   └── public/designs/              # HTML mockups copied here for local dev
├── MANIFEST.yaml                     # Master artifact registry
├── INDEX.md                          # Markdown design index
├── upload/                           # Staging area for new files
└── .github/workflows/deploy-gallery.yml
```

## File Types and Gallery Rendering

| File Type | Extension | Gallery Behavior |
|-----------|-----------|-----------------|
| JSX Mockup | `.jsx` | React.lazy() dynamic import, rendered in-page |
| HTML Mockup | `.html` | iframe embed via `htmlUrl` field, needs public/ copy |
| Figma | URL | iframe embed via `figmaUrl` field (/make/ → /embed/) |
| Spec (Markdown) | `.md` | Linked to GitHub blob via `specPath` |
| Spec-only | `.md` | Entry with `component: null`, no mockup panel |

## MANIFEST.yaml Entry Schema

```yaml
- id: unique-slug                    # Usually filename without extension
  type: mockup | spec | requirements-doc | research-doc | vendor-manual | reference-data | figma
  path: designs/category/filename.ext  # Repo-relative path
  category: admin-config | analyzer-integration | microbiology | nce | pathology | quality | results-validation | sample-collection | system | other
  description: Short human-readable summary
  paired_with: id-of-companion        # Optional: mockup ↔ spec link
  links:
    jira: [OGC-123]                   # Optional
    figma: [url]                      # Optional
    confluence: [url]                 # Optional
  added: "YYYY-MM-DD"
  updated: "YYYY-MM-DD"              # Optional
```

## App.jsx MOCKUP_REGISTRY Entry Patterns

### JSX Mockup with Spec
```js
{
  name: 'Feature Name',
  category: 'category-slug',
  component: React.lazy(() => import('@designs/category/filename.jsx')),
  description: 'Short description',
  specPath: 'designs/category/filename.md',
},
```

### HTML Mockup with Spec
```js
{
  name: 'Feature Name',
  category: 'category-slug',
  component: null,
  description: 'Short description',
  specPath: 'designs/category/filename.md',
  htmlUrl: 'designs/category/filename.html',
},
```

### Figma-only Entry
```js
{
  name: 'Feature Name',
  category: 'category-slug',
  component: null,
  description: 'Short description',
  specPath: null,
  figmaUrl: 'https://www.figma.com/make/...',
},
```

### Spec-only Entry (no mockup)
```js
{
  name: 'Feature Name',
  category: 'category-slug',
  component: null,
  description: 'Short description',
  specPath: 'designs/category/filename.md',
},
```

## INDEX.md Row Format

```markdown
| Feature Name | [filename.jsx](designs/category/filename.jsx) | [filename.md](designs/category/filename.md) |
```

Spec-only entries use `—` for the Mockup column.

## Permalink Generation

Base URL: `https://digi-uw.github.io/openelis-work/`

Slug function:
```js
name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
```

Full permalink: `https://digi-uw.github.io/openelis-work/#/category-slug/mockup-name-slug`

GitHub spec link: `https://github.com/digi-uw/openelis-work/blob/main/designs/category/filename.md`

## Categories (current)

| Slug | Label |
|------|-------|
| admin-config | Admin & Config |
| analyzer-integration | Analyzer Integration |
| microbiology | Microbiology |
| nce | NCE |
| pathology | Pathology |
| quality | Quality & EQA |
| results-validation | Results & Validation |
| sample-collection | Sample Collection |
| system | System |
| other | Other |

## HTML Mockup Serving

HTML mockups require TWO copies:
1. `designs/category/filename.html` — canonical location in repo
2. `mockup-viewer/public/designs/category/filename.html` — local dev serving

The deploy workflow copies `designs/**/*.html` into `mockup-viewer/dist/` at build time.

## File Naming Convention

All files use kebab-case: `feature-name-mockup.jsx`, `feature-name-spec.md`

When processing uploads with PascalCase or mixed naming, rename to kebab-case using `git mv` if already tracked, or just copy with new name if new.

## Build & Deploy

```bash
cd mockup-viewer && npm run build    # Vite build
# GitHub Actions deploys dist/ to GitHub Pages on push to main
```

## Commit Convention

All commits credit the author and co-author:
```
Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
```

The user pushes from their terminal (VM has no GitHub credentials).
