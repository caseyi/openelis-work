# Design Gallery Plugin

Process design mockups and specs into a browsable React gallery for the OpenELIS Global design workspace.

## Components

### Skills

| Skill | Trigger Phrases |
|-------|----------------|
| **process-design** | "I added new files", "process uploads", "add this to the gallery", "new spec uploaded" |
| **design-critique** | "critique this design", "review this mockup", "design feedback" |
| **spec-review** | "review this spec", "is this FRS complete", "check the requirements" |

### Commands

| Command | Description |
|---------|-------------|
| `/add-design [category] [description]` | Process uploaded files into the gallery |

## What It Does

**process-design** handles the full upload-to-gallery pipeline:
1. Discovers new files in `upload/`
2. Copies to `designs/<category>/` with kebab-case naming
3. Updates MANIFEST.yaml, App.jsx gallery registry, and INDEX.md
4. Builds the Vite gallery and verifies success
5. Commits and generates gallery permalinks

**design-critique** evaluates mockups against clinical lab UX, Carbon Design System, accessibility (WCAG 2.1 AA), and data safety best practices.

**spec-review** checks FRS documents for completeness, technical feasibility on the OpenELIS Spring Boot + React stack, and implementation readiness.

## Setup

This plugin is designed for the [openelis-work](https://github.com/DIGI-UW/openelis-work) repository. Mount the repo folder in Cowork, then install this plugin.

### Required repo structure

The plugin expects the standard gallery workspace:
- `upload/` — drop new files here
- `designs/` — co-located design files by category
- `mockup-viewer/` — Vite + React gallery app
- `MANIFEST.yaml` — artifact registry
- `INDEX.md` — markdown design index

## Usage

Drop files in `upload/` and say "I added new files" or run `/add-design`. The plugin handles the rest.
