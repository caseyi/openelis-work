---
description: Process uploaded design files into the gallery
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, TodoWrite
argument-hint: "<category> <description>"
---

Process any new files in the `upload/` folder into the design gallery.

1. List `upload/` sorted by date to find the newest files
2. Read the first 30 lines of each new file to understand its purpose
3. If $ARGUMENTS includes a category, use that; otherwise determine the best category from the file content
4. Copy files to `designs/<category>/` with kebab-case naming
5. For HTML mockups, also copy to `mockup-viewer/public/designs/<category>/`
6. Update MANIFEST.yaml, mockup-viewer/src/App.jsx, and INDEX.md with proper entries
7. Run `cd mockup-viewer && npm run build` and verify success
8. Stage and commit with a descriptive message ending with `Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>`
9. Output the full gallery permalink and GitHub spec link
10. Remind the user to `git push origin main`

Use the process-design skill for detailed format references.
