# Design Index — OpenELIS Global

Master index of all designs, specs, and handoff documents.

---

## Screens

| Screen | Mockup (JSX) | Spec | Handoff | Changelog | Status |
|--------|-------------|------|---------|-----------|--------|
| _Example: Sample Dashboard_ | [JSX](mockups/screens/_EXAMPLE_SampleDashboard.jsx) | — | — | — | Example |

## Components

| Component | Mockup (JSX) | Spec | Status |
|-----------|-------------|------|--------|

## Flows

| Flow | Mockup (JSX) | Spec | Status |
|------|-------------|------|--------|

---

## Quick Links

- **Figma Template:** [OpenELIS Global Template](https://www.figma.com/make/15B8LmoBhZ5WgtYDI9MCHm/OpenELIS-Global-Template)
- **Mockup Viewer:** Run `cd mockup-viewer && npm install && npm run dev`
- **Templates:** See [.templates/](.templates/) for spec, handoff, and changelog templates
