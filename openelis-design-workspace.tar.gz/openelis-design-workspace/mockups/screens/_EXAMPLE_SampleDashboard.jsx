/**
 * Example mockup — Sample Management Dashboard
 *
 * This is a placeholder to show how mockups are organized.
 * Replace with your actual JSX mockups from Claude artifacts.
 *
 * File naming convention:
 *   [FeatureName].jsx        — e.g., SampleManagement.jsx
 *   [FeatureName]_v2.jsx     — versioned variant
 *
 * After adding a mockup here, register it in:
 *   mockup-viewer/src/App.jsx → MOCKUP_REGISTRY
 */

import React from 'react';

export default function SampleDashboard() {
  return (
    <div style={{ fontFamily: "'IBM Plex Sans', sans-serif", padding: 24 }}>
      <h2 style={{ borderBottom: '2px solid #0f62fe', paddingBottom: 8 }}>
        Sample Management Dashboard
      </h2>
      <p style={{ color: '#525252' }}>
        This is a placeholder mockup. Replace this file with your actual JSX mockup
        from Claude, then register it in the MOCKUP_REGISTRY in App.jsx.
      </p>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: 16,
          marginTop: 24,
        }}
      >
        {['Pending', 'In Progress', 'Complete'].map((status) => (
          <div
            key={status}
            style={{
              border: '1px solid #e0e0e0',
              borderRadius: 8,
              padding: 16,
              textAlign: 'center',
            }}
          >
            <div style={{ fontSize: 28, fontWeight: 600, color: '#0f62fe' }}>0</div>
            <div style={{ color: '#6f6f6f', fontSize: 14 }}>{status}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
